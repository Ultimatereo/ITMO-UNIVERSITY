print("Hello from bar.__main__!")
