"""I am a happy module"""

foo = 'foobar'

def bar():
    return foo

print('Happy module is running!')
