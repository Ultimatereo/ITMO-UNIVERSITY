from cycle_foo import abc

xyz = 100
