from math import pi as _pi

some_string = 'some_string'

def get_circumference(radius):
    return 2 * _pi * radius
